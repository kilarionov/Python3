#       persons_db_app.py
import sqlite3


def menu() :
    print('0. Exit')
    print('1. Name Search')
    print('2. City Search')
    print('3. Phone Search')
    print('4. Show All Contacts')
    print('5. Add New Contact')
    inp = input('Enter A Number?')
    if len(inp) == 0 :
        return 'Invalid Choice'
    else :
        return inp[0]


def exitMe() :
    conn.close()


def searc_by_name(name) :
    pass


def search_by_city(town) :
    pass


def search_by_phone(number) :
    pass


def show_all_contacts() :
    c.execute("SELECT names, city, phone FROM contacts")
    print(*c.fetchall())


def add_contact() :
    names = input('Names ?')
    city = input('City ?')
    phone = input('Phone ?')
    sql_cmd = f"INSERT INTO contacts VALUES ('{names}', '{city}', {phone})"
    c.execute(sql_cmd)

    conn.commit()



DB_NAME = 'persons.db'
conn = sqlite3.connect(DB_NAME)
c = conn.cursor()

c.execute('''CREATE TABLE IF NOT EXISTS contacts (
            names text,
            city text,
            phone text UNIQUE)''')  # ??? phones


while True :
    choise = menu()
    if choise == '0' :
        exitMe()
        break
    elif choise == '1' :
        searc_by_name('someName')
    elif choise == '2' :
        search_by_city('SomeCity')
    elif choise == '3' :
        search_by_phone('SomePhone')
    elif choise == '4' :
        show_all_contacts()
    elif choise == '5' :
        add_contact()

print('YOU EXIT SUCCESSFULLY')
